package com.capstone.team3.pojo;

public class CapstonePojo {
	
	private int id;
	private String username;
	private String name;
	private String password;
	private String role;
	private String status;
	private String activefrom;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActivefrom() {
		return activefrom;
	}
	public void setActivefrom(String activefrom) {
		this.activefrom = activefrom;
	}
	

}
