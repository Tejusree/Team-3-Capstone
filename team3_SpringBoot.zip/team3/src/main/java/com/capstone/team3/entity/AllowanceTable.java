package com.capstone.team3.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AllowanceTable {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
    private int id;
	private int ResourceId;
	private String ResourceName;
	private String periodStart;
	private String periodEnd;
	private int hours;
	private String approvalStatus;
	private String timeSheetNumber;
	private String vertical;
	private String horizontal;
	private String subhorizontal;
	private String customerId;
	private String customerName;
	private String projectId;
	private String projectName;
	private String projectManager;
	public AllowanceTable(int id, int resourceId, String resourceName, String periodStart, String periodEnd, int hours,
			String approvalStatus, String timeSheetNumber, String vertical, String horizontal, String subhorizontal,
			String customerId, String customerName, String projectId, String projectName, String projectManager) {
		super();
		this.id = id;
		this.ResourceId = resourceId;
		this.ResourceName = resourceName;
		this.periodStart = periodStart;
		this.periodEnd = periodEnd;
		this.hours = hours;
		this.approvalStatus = approvalStatus;
		this.timeSheetNumber = timeSheetNumber;
		this.vertical = vertical;
		this.horizontal = horizontal;
		this.subhorizontal = subhorizontal;
		this.customerId = customerId;
		this.customerName = customerName;
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectManager = projectManager;
	}
	public AllowanceTable()
	{
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getResourceId() {
		return ResourceId;
	}
	public void setResourceId(int resourceId) {
		ResourceId = resourceId;
	}
	public String getResourceName() {
		return ResourceName;
	}
	public void setResourceName(String resourceName) {
		ResourceName = resourceName;
	}
	public String getPeriodStart() {
		return periodStart;
	}
	public void setPeriodStart(String periodstart) {
		this.periodStart = periodstart;
	}
	public String getPeriodEnd() {
		return periodEnd;
	}
	public void setPeriodEnd(String periodEnd) {
		this.periodEnd = periodEnd;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getTimeSheetNumber() {
		return timeSheetNumber;
	}
	public void setTimeSheetNumber(String timeSheetNumber) {
		this.timeSheetNumber = timeSheetNumber;
	}
	public String getVertical() {
		return vertical;
	}
	public void setVertical(String vertical) {
		this.vertical = vertical;
	}
	public String getHorizontal() {
		return horizontal;
	}
	public void setHorizontal(String horizontal) {
		this.horizontal = horizontal;
	}
	public String getSubhorizontal() {
		return subhorizontal;
	}
	public void setSubhorizontal(String subhorizontal) {
		this.subhorizontal = subhorizontal;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	
}
