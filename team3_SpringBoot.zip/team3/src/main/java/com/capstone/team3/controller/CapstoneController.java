package com.capstone.team3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.team3.entity.CapstoneEntity;
import com.capstone.team3.pojo.CapstonePojo;
import com.capstone.team3.service.CapstoneService;

@CrossOrigin
@RestController
public class CapstoneController {
	
	@Autowired
	private CapstoneService capstoneservice;
	
	@CrossOrigin("http://localhost:3000")
	@PostMapping(value="/mailExist")
	public boolean checkMailExists(String userRecipient)
	{
		System.out.println(userRecipient);
		return capstoneservice.checkMailExists(userRecipient);
	}
	
	
	@PostMapping("/mailWithOtp")
	public String sendMailWithOtp(String recipient, String msgBody, String subject)
	{
		System.out.println( recipient);
		String status= capstoneservice.sendMailWithAttachment(recipient, msgBody, subject); 
        return status;
	}
	
	@PostMapping("/updatepassword")
	public boolean changepassword(String email,String pass)
	{
		System.out.println("Entered changed password");
		System.out.println(email+" "+pass);
		capstoneservice.changepassword(email,pass);
		return true;
	}
	
	
	@PostMapping(value = "/save")
	public CapstonePojo saveUser(@RequestBody CapstonePojo capstonepojo) {
		       System.out.println("Entered Post save method");
               return capstoneservice.save(capstonepojo);
        }
	
	
	
	
	@GetMapping(value="/get/{username}")
	public CapstoneEntity getUserByUname(@PathVariable String username)
	{
		String arr[] = username.split("_");
		String newusername = arr[0];
		for(int i=1;i<arr.length;i++)
		{
			newusername = newusername+" "+arr[i];
		}
		System.out.println(newusername);
		CapstoneEntity user =  capstoneservice.findUserByUname(newusername);
		System.out.println("Entered get by username and password method");
		System.out.println(user);
		return user;
		
	}
	
	@GetMapping(value="/getByUserName/{username}")
	public CapstoneEntity getByUserName(@PathVariable String username)
	{
		String arr[] = username.split("_");
		String newusername = arr[0];
		for(int i=1;i<arr.length;i++)
		{
			newusername = newusername+" "+arr[i];
		}
		System.out.println(newusername);
		CapstoneEntity user = capstoneservice.getByUserName(newusername);
		System.out.println(user);
		return user;
	}
	
	@GetMapping(value="/getdata")
	public List<CapstoneEntity> getdata()
	{
		List<CapstoneEntity> list = capstoneservice.getdata();
		return list;
	}
	
    @PutMapping(value="/updateByRoleStatus/{username}/{role}/{status}")
    public void updateUserByRoleStatus(@PathVariable String username,@PathVariable String role,@PathVariable String status)
    {
       capstoneservice.updateUserByRoleStatus(username,role,status);
 
    }
    
    @PutMapping(value="/updateByRole/{username}/{role}")
    public void updateUserByRole(@PathVariable String username,@PathVariable String role)
    {
       capstoneservice.updateUserByRole(username,role);
 
    }
    
    @PutMapping(value="/updateByStatus/{username}/{status}")
    public void updateUserByUserName(@PathVariable String username,@PathVariable String status)
    {
       capstoneservice.updateUserByStatus(username,status);
 
    }
    
    @DeleteMapping(value="/delete/{username}")
    public void deleteByUserName(@PathVariable String username)
    {
    	capstoneservice.deleteByUserName(username);
    }
}
