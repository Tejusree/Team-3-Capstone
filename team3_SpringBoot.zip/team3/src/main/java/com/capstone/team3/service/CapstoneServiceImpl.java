package com.capstone.team3.service;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.capstone.team3.entity.CapstoneEntity;
import com.capstone.team3.pojo.CapstonePojo;
import com.capstone.team3.repository.CapstoneRepository;


@Service
public class CapstoneServiceImpl implements CapstoneService{
	

	@Autowired
	CapstoneRepository capstonerepository;
	private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	
	@Autowired 
	private JavaMailSender javaMailSender;
	private String sender = "teja.mb@incedoinc.com";

	@Override
	public CapstonePojo save(CapstonePojo capstonepojo) {
		// TODO Auto-generated method stub
		CapstoneEntity user = new CapstoneEntity();
		user.setName(capstonepojo.getName());
		String testPasswordEncoded = passwordEncoder.encode(capstonepojo.getPassword());
		user.setPassword(testPasswordEncoded);
		//user.setPassword(capstonepojo.getPassword());
		user.setRole(capstonepojo.getRole());
		user.setStatus(capstonepojo.getStatus());
		user.setUsername(capstonepojo.getUsername());
		user.setActivefrom(capstonepojo.getActivefrom());
		
		CapstoneEntity u = capstonerepository.save(user);
		
		capstonepojo.setId(u.getId());
		capstonepojo.setName(u.getName());
		capstonepojo.setPassword(u.getPassword());
		capstonepojo.setRole(u.getRole());
		capstonepojo.setStatus(u.getStatus());
		capstonepojo.setUsername(u.getUsername());
		capstonepojo.setActivefrom(u.getActivefrom());
		return capstonepojo;
		}
	    
	   
		@Override
		public CapstoneEntity findUserByUname(String username) {
			// TODO Auto-generated method stub
			return capstonerepository.findUserByUnameAndPwd(username);
		}


		@Override
		public CapstoneEntity getByUserName(String username) {
		
			return capstonerepository.getByUserName(username);
		}


		@Override
		public List<CapstoneEntity> getdata() {
			// TODO Auto-generated method stub
			return capstonerepository.findAll();
		}


		


		@Override
		public void deleteByUserName(String username) {
			capstonerepository.deleteByUserName(username);
			
		}


		@Override
		public void updateUserByRoleStatus(String username, String role, String status) {
			// TODO Auto-generated method stub
			capstonerepository.updateUserByRoleStatus(username,role,status);
			
		}


		@Override
		public void updateUserByRole(String username, String role) {
			// TODO Auto-generated method stub
			capstonerepository.updateUserByRole(username,role);
			
		}


		@Override
		public void updateUserByStatus(String username, String status) {
			// TODO Auto-generated method stub
			capstonerepository.updateUserByStatus(username,status);
			
		}


		@Override
		public boolean checkMailExists(String userRecipient) {
			// TODO Auto-generated method stub
			CapstoneEntity user = capstonerepository.findUserByUname(userRecipient);
			System.out.println(user);
			if(user != null)
			{
				return true;
			}
			return false;
		}


		@Override
		public String sendMailWithAttachment(String recipient, String msgBody, String subject) {
			// TODO Auto-generated method stub

	        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
	        MimeMessageHelper mimeMessageHelper;
	        
	        try {
	        	 
	            System.out.println("hi");
	            mimeMessageHelper= new MimeMessageHelper(mimeMessage, true);
	            mimeMessageHelper.setFrom(sender);
	            mimeMessageHelper.setTo(recipient);
	            mimeMessageHelper.setText(msgBody);
	            mimeMessageHelper.setSubject(subject);
	            javaMailSender.send(mimeMessage);
	            return "Mail sent Successfully";
	        }
	 
	       
	        catch (MessagingException e) 
	        {
	            return "Error while sending mail!!!";
	        }
	    }


		@Override
		public void changepassword(String email, String password) {
			// TODO Auto-generated method stub
			System.out.println("Entered service change password");
			capstonerepository.updateChangedPassword(email,password);
			
			
		}
		
}


		


		
			
			


