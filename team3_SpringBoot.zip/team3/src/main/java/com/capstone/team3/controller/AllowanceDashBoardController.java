package com.capstone.team3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.team3.entity.AllowanceDashBoard;
import com.capstone.team3.service.AllowanceDashBoardService;

@RestController
@CrossOrigin
public class AllowanceDashBoardController {
	
	@Autowired
	private AllowanceDashBoardService allowancedashboardservice;
	
	@GetMapping("/getEmployeeAllowanceDashBoard/{projectname}/{startdate}/{enddate}/{name}")
	public List<AllowanceDashBoard> getEmployeeAllowanceDashBoard(@PathVariable String projectname,@PathVariable String startdate,@PathVariable String enddate,@PathVariable String name)
	{
		String userarray[] = name.split("_");
		String temp = userarray[0];
		for(int i=1;i<userarray.length;i++)
		{
			temp = temp+" "+userarray[i];
		}
		return allowancedashboardservice.getEmployeeAllowanceDashBoard(projectname,startdate,enddate,temp);
	}
	
	@GetMapping("/getAllowanceDashBoardADB/{username}")
	public List<AllowanceDashBoard>getAllowanceDashBoardByProjectManager(@PathVariable String username)
	{
		return allowancedashboardservice.getAllowanceDashBoardByProjectManagerName(username);
	}
	
	@GetMapping("/getAllowanceDashBoardByUserName/{username}")
	public List<AllowanceDashBoard> getAllowanceDashBoardByUserName(@PathVariable String username)
	{
		System.out.println(username+" "+"Entered controller");
		String userarray[] = username.split("_");
		String temp = userarray[0];
		for(int i=1;i<userarray.length;i++)
		{
			temp = temp+" "+userarray[i];
		}
		List<AllowanceDashBoard> list = allowancedashboardservice.getAllowanceDashBoardByUserName(temp);
		System.out.println(list);
		return list;
	}
	
	@GetMapping("/getAllowanceDashBoardADB")
	public List<AllowanceDashBoard> getAllowanceDashBoardADB()
	{
		System.out.println("Entering get Allowance dashboard");
		return allowancedashboardservice.getAllowanceDashBoardADB();
	}
	
	@GetMapping("/saveAllowanceDashBoard/{projectname1}/{projectname2}")
	public void saveAllowanceDashBoard(@PathVariable String projectname1,@PathVariable String projectname2)
	{
		allowancedashboardservice.getAllowanceTableWithNoHolidaysLeaves(projectname1,projectname2);
		
	}
	
	@GetMapping("getAllowanceDashBoardById/{id}")
	public AllowanceDashBoard getAllowanceDashBoardById(@PathVariable String id)
	{
		int iid = Integer.parseInt(id);
		return allowancedashboardservice.getAllowanceDashBoardById(iid);
	}
	
	@PutMapping("updateUserAllowanceDashBoard/{afsd}/{nsd}/{defta}/{tpallowance}/{toallowance}/{id}/{status}")
	public String updateUserAllowanceDashBoard(@PathVariable String afsd,@PathVariable String nsd,@PathVariable String defta,@PathVariable String tpallowance,@PathVariable String toallowance,@PathVariable String id,@PathVariable String status)
	{
		int iid = Integer.parseInt(id);
		int iafsd = Integer.parseInt(afsd);
		int insd = Integer.parseInt(nsd);
		int idefta = Integer.parseInt(defta);
		int itpallowance = Integer.parseInt(tpallowance);
		int itoallowance = Integer.parseInt(toallowance);
	    allowancedashboardservice.updateUserAllowanceDashBoard(iafsd,insd,idefta,itpallowance,itoallowance,iid,status);	
	    return "Successfully updated";
	}
	
	@GetMapping("getAllowanceDashBoardByPnSdEdAs/{projectname}/{startdate}/{enddate}/{approvalstatus}/{projectmanagername}")
	public List<AllowanceDashBoard> getAllowanceDashBoardByPnSdEdAs(@PathVariable String projectname,@PathVariable String startdate,@PathVariable String enddate,@PathVariable String approvalstatus,@PathVariable String projectmanagername)
	{
		String arr[] = projectmanagername.split("_");
		String pmname = arr[0];
		for(int i=1;i<arr.length;i++)
		{
			pmname = pmname +" "+arr[i]; 
		}
		return allowancedashboardservice.getAllowanceDashBoardByPnSdEdAs(projectname,startdate,enddate,approvalstatus,pmname);
	}
	
	@GetMapping("getAllowanceDashBoardByPnSdEdAsNpm/{projectname}/{startdate}/{enddate}/{approvalstatus}")
    public List<AllowanceDashBoard> getAllowanceDashBoardByPnSdEdAsNpm(@PathVariable String projectname,@PathVariable String startdate,@PathVariable String enddate,@PathVariable String approvalstatus)
    {
        return allowancedashboardservice.getAllowanceDashBoardByPnSdEdAsNpm(projectname,startdate,enddate,approvalstatus);
    }
	

}
