package com.capstone.team3.helper;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.capstone.team3.entity.AllowanceTable;

public class AllowanceHelper {
	
	//Check whether the uploaded file is of xlsl format or not.
	public static boolean checkExcelFileFormat(MultipartFile file)
	{
		String contentType = file.getContentType();
		if(contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
	    {
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//method to convert excel data to List of AllowanceTable objects
	public static List<AllowanceTable> convertExcelToListOfATObjects(InputStream is)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		
		List<AllowanceTable> list = new ArrayList<>();
		try 
		{
			  XSSFWorkbook workbook = new XSSFWorkbook(is);
			  XSSFSheet sheet = workbook.getSheet("TimesheetComplaince");
			  int rownumber = 0;
			  Iterator<Row> iterator =  sheet.iterator();
			  while(iterator.hasNext())
			  {
				  Row row = iterator.next();
				  if(rownumber == 0)
				  {
					  rownumber++;
					  continue;
				  }
				  Iterator<Cell> cells = row.iterator();
				  int cellid = 0;
				  AllowanceTable a = new AllowanceTable();
				  while(cells.hasNext())
				  {
					  Cell cell = cells.next();
					  switch(cellid)
					  {
					      case 0:
					    	  a.setResourceName(cell.getStringCellValue());
					    	  break;
					      case 1:
					    	  a.setResourceId((int)cell.getNumericCellValue());
					    	  break;
					      case 2:
					    	  a.setPeriodStart(formatter.format(cell.getDateCellValue()));
					    	  break;
					      case 3:
					    	  a.setPeriodEnd(formatter.format(cell.getDateCellValue()));
					    	  break;
					      case 4:
					    	  a.setHours((int)cell.getNumericCellValue());
					    	  break;
					      case 5:
					    	  a.setApprovalStatus(cell.getStringCellValue());
					    	  break;
					      case 6:
					    	  a.setTimeSheetNumber(cell.getStringCellValue());
					    	  break;
					      case 7:
					    	  a.setVertical(cell.getStringCellValue());
					    	  break;
					      case 8:
					    	  a.setHorizontal(cell.getStringCellValue());
					    	  break;
					      case 9:
					    	  a.setSubhorizontal(cell.getStringCellValue());
					    	  break;
					      case 10:
					    	  a.setCustomerId(cell.getStringCellValue());
					    	  break;
					      case 11:
					    	  a.setCustomerName(cell.getStringCellValue());
					    	  break;
					      case 12:
					    	  a.setProjectId(cell.getStringCellValue());
					    	  break;
					      case 13:
					    	  a.setProjectName(cell.getStringCellValue());
					    	  break;
					      case 14:
					    	  a.setProjectManager(cell.getStringCellValue());
					    	  break;
					      default:
					    	  break;
					     
					  }
					  cellid++;
				  }
				  list.add(a);
				  
			  }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
		
		
	}

}
