package com.capstone.team3.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="allowance_dashboard")
public class AllowanceDashBoard {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private int id;
	private String name;
	private int sapid;
	private int projecthours;
	private int holidayleavehours;
	private int afternoonshiftdays;
	private int nightshiftdays;
	private int dayseligibleforta;
	private int transportallowance;
	private int totalallowance;
	private String projectname;
	private String startdate;
	private String enddate;
	private String status;
	private String projectmanagername;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSapid() {
		return sapid;
	}
	public void setSapid(int sapid) {
		this.sapid = sapid;
	}
	public int getProjecthours() {
		return projecthours;
	}
	public void setProjecthours(int projecthours) {
		this.projecthours = projecthours;
	}
	public int getHolidayleavehours() {
		return holidayleavehours;
	}
	public void setHolidayleavehours(int holidayleavehours) {
		this.holidayleavehours = holidayleavehours;
	}
	public int getAfternoonshiftdays() {
		return afternoonshiftdays;
	}
	public void setAfternoonshiftdays(int afternoonshiftdays) {
		this.afternoonshiftdays = afternoonshiftdays;
	}
	public int getNightshiftdays() {
		return nightshiftdays;
	}
	public void setNightshiftdays(int nightshiftdays) {
		this.nightshiftdays = nightshiftdays;
	}
	public int getDayseligibleforta() {
		return dayseligibleforta;
	}
	public void setDayseligibleforta(int dayseligibleforta) {
		this.dayseligibleforta = dayseligibleforta;
	}
	public int getTransportallowance() {
		return transportallowance;
	}
	public void setTransportallowance(int transportallowance) {
		this.transportallowance = transportallowance;
	}
	public int getTotalallowance() {
		return totalallowance;
	}
	public void setTotalallowance(int totalallowance) {
		this.totalallowance = totalallowance;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProjectmanagername() {
		return projectmanagername;
	}
	public void setProjectmanagername(String projectmanagername) {
		this.projectmanagername = projectmanagername;
	}

}
