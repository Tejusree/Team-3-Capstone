package com.capstone.team3.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstone.team3.entity.CapstoneEntity;



@Repository
public interface CapstoneRepository extends JpaRepository<CapstoneEntity,Integer>{
	

	
	@Query("SELECT u FROM CapstoneEntity u where u.username = :username")
	CapstoneEntity findUserByUnameAndPwd(@Param("username")String username);
	
	@Query("SELECT u FROM CapstoneEntity u where u.name = :username")
	CapstoneEntity getByUserName(@Param("username")String username);
	
	@Query("SELECT u FROM CapstoneEntity u where u.username = :userrecipient")
	CapstoneEntity findUserByUname(@Param("userrecipient") String userrecipient);
	
	@Transactional
	@Modifying
	@Query("UPDATE CapstoneEntity u SET u.status = :status, u.role = :role where u.username = :username")
	void updateUserByRoleStatus(@Param("username") String username,@Param("role")String role,@Param("status")String status);
	
	@Transactional
	@Modifying
	@Query("UPDATE CapstoneEntity u SET u.status = :status where u.username = :username")
	void updateUserByStatus(@Param("username") String username,@Param("status")String status);
	
	@Transactional
	@Modifying
	@Query("UPDATE CapstoneEntity u SET u.role = :role where u.username = :username")
	void updateUserByRole(@Param("username") String username,@Param("role")String role);
	
	@Transactional
	@Modifying
	@Query("DELETE CapstoneEntity u where u.username = :username")
	void deleteByUserName(@Param("username")String username);
	
	@Transactional
	@Modifying
	@Query("UPDATE CapstoneEntity u SET u.password = :password where u.username = :username")
	void updateChangedPassword(@Param("username")String username,@Param("password") String password);
	
	

}
