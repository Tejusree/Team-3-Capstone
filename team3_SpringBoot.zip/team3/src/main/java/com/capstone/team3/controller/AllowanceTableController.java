package com.capstone.team3.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capstone.team3.entity.AllowanceTable;
import com.capstone.team3.helper.AllowanceHelper;
import com.capstone.team3.service.AllowanceTableService;

@RestController
@CrossOrigin
public class AllowanceTableController {
	
	@Autowired
	private AllowanceTableService allowancetableservice;
	
	@PostMapping("/allowancetable/allowances")
	public String upload(@RequestParam("file")MultipartFile file)
	{
		String message="";
		if(AllowanceHelper.checkExcelFileFormat(file))
		{
			//if it is excel file:true
			allowancetableservice.save(file);
			message = "File uploaded Successfully";
		}
		else
		{
			message = "The file you have uploaded is not excel file";
		}
		return message;
		
	}
	
	@GetMapping("/allowances")
	public List<AllowanceTable> getallallowances()
	{
		return allowancetableservice.getallallowances();
	}
	
//	@GetMapping(value="/getAllowanceDashBoard/{projectname}/{startdate}/{enddate}")
//	public List<AllowanceTable> getAllowanceDashBoard(@PathVariable String projectname,@PathVariable String startdate,@PathVariable String enddate)
//	{
//		
//		return allowancetableservice.getAllowanceDashBoard(projectname,startdate,enddate);
//		
//	}

}
