package com.capstone.team3.service;

import java.util.List;

import com.capstone.team3.entity.CapstoneEntity;
import com.capstone.team3.pojo.CapstonePojo;


public interface CapstoneService {
	
	CapstonePojo save(CapstonePojo capstonepojo);
	CapstoneEntity findUserByUname(String username);
	CapstoneEntity getByUserName(String username);
	List<CapstoneEntity> getdata();
	void updateUserByRoleStatus(String username,String role,String status);
	void updateUserByRole(String username,String role);
	void updateUserByStatus(String username,String status);
	void deleteByUserName(String username);
	boolean checkMailExists(String userRecipient);
	String sendMailWithAttachment(String recipient, String msgBody, String subject);
	void changepassword(String email,String password);

}
