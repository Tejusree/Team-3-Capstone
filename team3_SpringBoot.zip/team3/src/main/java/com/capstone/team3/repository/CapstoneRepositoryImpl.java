package com.capstone.team3.repository;

public class CapstoneRepositoryImpl {

}
