   package com.capstone.team3.repository;

   import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstone.team3.entity.AllowanceDashBoard;
import com.capstone.team3.entity.AllowanceTable;

    @Repository
    public interface AllowanceDashBoardRepository extends JpaRepository<AllowanceDashBoard,Integer>{

    @Query("SELECT u FROM AllowanceTable u where u.projectName != :projectname1 AND u.projectName != :projectname2")
    List<AllowanceTable> getAllowanceTableWithNoHolidaysLeaves(@Param("projectname1")String projectname1,@Param("projectname2")String projectname2);

    @Query("SELECT u FROM AllowanceTable u where u.projectName = :projectname1 OR u.projectName = :projectname2")
    List<AllowanceTable> getAllowanceTableWithOnlyHolidaysLeaves(@Param("projectname1")String projectname1,@Param("projectname2")String projectname2);

    @Transactional
    @Modifying
	@Query("UPDATE AllowanceDashBoard a SET a.holidayleavehours = :projecthours where a.name = :name AND a.startdate = :startdate AND a.enddate = :enddate")
    void updateAllowanceDashBoardWithHolidayHours(@Param("name")String name,@Param("startdate")String startdate,@Param("enddate")String enddate,@Param("projecthours")int hours);
	
    @Query("SELECT a FROM AllowanceDashBoard a where a.projectmanagername = :pmname")
	List<AllowanceDashBoard> getAllowanceDashBoardByProjectManagerName(@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a where a.id = :id")
    AllowanceDashBoard getAllowanceDashBoardById(@Param("id")int id);
    
    @Transactional
    @Modifying
    @Query("UPDATE AllowanceDashBoard a SET a.afternoonshiftdays = :afsd , a.nightshiftdays = :nsd , a.dayseligibleforta = :defta , a.transportallowance =:tpallowance , a.totalallowance = :toallowance , a.status = :status where a.id = :id")
    void updateUserAllowanceDashBoard(@Param("afsd") int afsd,@Param("nsd") int nsd,@Param("defta") int defta,@Param("tpallowance") int tpallowance,@Param("toallowance") int toallowance,@Param("id")int id,@Param("status") String status);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardCETALL(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 ) AND a.startdate >= :startdate AND a.enddate  <= :enddate AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardEPALL(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDataALL(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalALL(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardCETApproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardEPApproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDataApproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status =:status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalApproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
     
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardCETUnapproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardEPUnapproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDataUnapproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status AND a.projectmanagername = :pmname")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalUnapproved(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("pmname") String pmname);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where a.name = :username")
    List<AllowanceDashBoard> getAllowanceDashBoardByUserName(@Param("username") String username);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.name = :name")
    List<AllowanceDashBoard> getEmployeeAllowanceDashBoardByCET(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("name") String name);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.name = :name")
    List<AllowanceDashBoard> getEmployeeAllowanceDashBoardByEP(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("name") String name);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.name = :name")
    List<AllowanceDashBoard> getEmployeeAllowanceDashBoardByData(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("name") String name);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.name = :name")
    List<AllowanceDashBoard> getEmployeeAllowanceDashBoardByDigital(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("startdate") String startdate,@Param("enddate") String enddate,@Param("name") String name);
    
    //superuser
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate ")
    List<AllowanceDashBoard> getAllowanceDashBoardCETALLNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 ) AND a.startdate >= :startdate AND a.enddate  <= :enddate")
    List<AllowanceDashBoard> getAllowanceDashBoardEPALLNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate")
    List<AllowanceDashBoard> getAllowanceDashBoardDataALLNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalALLNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status")
    List<AllowanceDashBoard> getAllowanceDashBoardCETApprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status")
    List<AllowanceDashBoard> getAllowanceDashBoardEPApprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status = :status ")
    List<AllowanceDashBoard> getAllowanceDashBoardDataApprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status =:status")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalApprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
     
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status")
    List<AllowanceDashBoard> getAllowanceDashBoardCETUnapprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status")
    List<AllowanceDashBoard> getAllowanceDashBoardEPUnapprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status")
    List<AllowanceDashBoard> getAllowanceDashBoardDataUnapprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    
    @Query("SELECT a FROM AllowanceDashBoard a Where (a.projectname = :pname1 OR a.projectname = :pname2 OR a.projectname = :pname3 OR a.projectname = :pname4 OR a.projectname = :pname5 OR a.projectname = :pname6 OR a.projectname = :pname7 OR a.projectname = :pname8) AND a.startdate >= :startdate AND a.enddate <= :enddate AND a.status != :status")
    List<AllowanceDashBoard> getAllowanceDashBoardDigitalUnapprovedNpm(@Param("pname1") String pname1,@Param("pname2") String pname2,@Param("pname3") String pname3,@Param("pname4") String pname4,@Param("pname5") String pname5,@Param("pname6") String pname6,@Param("pname7") String pname7,@Param("pname8") String pname8,@Param("status") String status,@Param("startdate") String startdate,@Param("enddate") String enddate);
    }
