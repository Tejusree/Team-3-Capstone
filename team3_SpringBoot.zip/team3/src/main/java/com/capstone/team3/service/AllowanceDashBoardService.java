package com.capstone.team3.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.team3.entity.AllowanceDashBoard;
import com.capstone.team3.entity.AllowanceTable;
import com.capstone.team3.repository.AllowanceDashBoardRepository;

@Service
public class AllowanceDashBoardService {
	
	@Autowired
	private AllowanceDashBoardRepository allowancedashboardrepository;
	
	public List<AllowanceDashBoard> getAllowanceDashBoardADB()
	{
		return allowancedashboardrepository.findAll();
	}
	
	public List<AllowanceDashBoard> getAllowanceDashBoardByProjectManagerName(String pmname)
	{
		return allowancedashboardrepository.getAllowanceDashBoardByProjectManagerName(pmname);
	}
	
	public void getAllowanceTableWithNoHolidaysLeaves(String projectname1,String projectname2)
	{
		List<AllowanceTable> list = allowancedashboardrepository.getAllowanceTableWithNoHolidaysLeaves(projectname1, projectname2);
		List<AllowanceTable> olist = allowancedashboardrepository.getAllowanceTableWithOnlyHolidaysLeaves(projectname1,projectname2);
		System.out.println(olist.size());
		List<AllowanceDashBoard> rlist = new ArrayList<>();
		Iterator<AllowanceTable> mylist = list.iterator();
		while(mylist.hasNext())
		{
			AllowanceTable at = mylist.next();
			AllowanceDashBoard adb = new AllowanceDashBoard();
			adb.setName(at.getResourceName());
			adb.setSapid(at.getResourceId());
			adb.setProjecthours(at.getHours());
			adb.setProjectname(at.getProjectName());
			adb.setStartdate(at.getPeriodStart());
			adb.setEnddate(at.getPeriodEnd());
			adb.setStatus(at.getApprovalStatus());
			adb.setAfternoonshiftdays(at.getHours()/8);
			adb.setDayseligibleforta(adb.getAfternoonshiftdays()+adb.getNightshiftdays());
			adb.setTransportallowance(adb.getDayseligibleforta()*300);
			adb.setTotalallowance(adb.getTransportallowance()+1000);
			adb.setProjectmanagername(at.getProjectManager());
			rlist.add(adb);
		}
		Iterator<AllowanceTable> mylist2 = olist.iterator();
		allowancedashboardrepository.saveAll(rlist);
		int count = 0;
		while(mylist2.hasNext())
		{
			AllowanceTable at = mylist2.next();
			allowancedashboardrepository.updateAllowanceDashBoardWithHolidayHours(at.getResourceName(),at.getPeriodStart(),at.getPeriodEnd(),at.getHours());
			
			if(count<5)
			{
				System.out.println(at.getResourceName()+" "+at.getPeriodEnd()+" "+at.getPeriodEnd()+" "+at.getHours());
				count++;
			}
		}
	}
	
	public List<AllowanceDashBoard> getAllowanceDashBoardByUserName(String username)
	{
		System.out.println(username+" Entered service");
		return allowancedashboardrepository.getAllowanceDashBoardByUserName(username);
	}
	
	public AllowanceDashBoard getAllowanceDashBoardById(int id)
	{
		return allowancedashboardrepository.getAllowanceDashBoardById(id);
	}
	
	public void updateUserAllowanceDashBoard(int afsd,int nsd,int defta,int tpallowance,int toallowance,int id,String status)
	{
		  allowancedashboardrepository.updateUserAllowanceDashBoard(afsd,nsd,defta,tpallowance,toallowance,id,status);
	}
	
	public List<AllowanceDashBoard> getEmployeeAllowanceDashBoard(String projectname,String startdate,String enddate,String name)
	{
		if(projectname.equals("CET"))
	    {
			String pname1 = "AssetMark Backoffice";
			String pname2 = "Investment";
			String pname3 = "CET Applications Support";
			String pname4 = "QA Project";
			return allowancedashboardrepository.getEmployeeAllowanceDashBoardByCET(pname1,pname2,pname3,pname4,startdate,enddate,name);
		}
		else if(projectname.equals("Enterprise Platforms"))
		{
			String pname1 = "AssetMark infra Services";
			String pname2 = "Investment Operations";
			String pname3 = "eSigna";
			String pname4 = "Sitecore";
			String pname5 = "SFDC";
			String pname6 = "OKTA Implementation";
			return allowancedashboardrepository.getEmployeeAllowanceDashBoardByEP(pname1,pname2,pname3,pname4,pname5,pname6,startdate,enddate,name);
		}
		else if(projectname.equals("Data"))
		{
			String pname1 = "HNW Reporting and Enhancements";
			String pname2 = "Integrated Digital Insights Squad";
			String pname3 = "Batch Processing";
			return allowancedashboardrepository.getEmployeeAllowanceDashBoardByData(pname1,pname2,pname3,startdate,enddate,name);
		}
		else if(projectname.equals("Digital"))
		{
			String pname1 = "Digital User Experience";
			String pname2 = "IT Platforms";
			String pname3 = "Digital Applications";
			String pname4 = "DevOps";
			String pname5 = "Ops Enhancements";
			String pname6 = "App Dev";
			String pname7 = "Savos Personal Portfolios";
			String pname8 = "Delivery Management_AssetMark";
			return allowancedashboardrepository.getEmployeeAllowanceDashBoardByDigital(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,startdate,enddate,name);
			
		}
		return null;
	}
	
	public List<AllowanceDashBoard> getAllowanceDashBoardByPnSdEdAs(String projectname,String startdate,String enddate,String approvalstatus,String pmname)
	{
		if(projectname.equals("CET")  && approvalstatus.equals("All"))
		{
			String pname1 = "AssetMark Backoffice";
			String pname2 = "Investment";
			String pname3 = "CET Applications Support";
			String pname4 = "QA Project";
		    return allowancedashboardrepository.getAllowanceDashBoardCETALL(pname1,pname2,pname3,pname4,startdate,enddate,pmname);	
		}
		else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("All"))
		{
			String pname1 = "AssetMark infra Services";
			String pname2 = "Investment Operations";
			String pname3 = "eSigna";
			String pname4 = "Sitecore";
			String pname5 = "SFDC";
			String pname6 = "OKTA Implementation";
			return allowancedashboardrepository.getAllowanceDashBoardEPALL(pname1,pname2,pname3,pname4,pname5,pname6,startdate,enddate,pmname);
		}
		else if(projectname.equals("Data") && approvalstatus.equals("All"))
		{
			System.out.println(projectname+" "+approvalstatus+" "+startdate+" "+enddate+" "+pmname);
			String pname1 = "HNW Reporting and Enhancements";
			String pname2 = "Integrated Digital Insights Squad";
			String pname3 = "Batch Processing";
			return allowancedashboardrepository.getAllowanceDashBoardDataALL(pname1,pname2,pname3,startdate,enddate,pmname);
		}
		else if(projectname.equals("Digital") && approvalstatus.equals("All"))
		{
			String pname1 = "Digital User Experience";
			String pname2 = "IT Platforms";
			String pname3 = "Digital Applications";
			String pname4 = "DevOps";
			String pname5 = "Ops Enhancements";
			String pname6 = "App Dev";
			String pname7 = "Savos Personal Portfolios";
			String pname8 = "Delivery Management_AssetMark";
			return allowancedashboardrepository.getAllowanceDashBoardDigitalALL(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,startdate,enddate,pmname);
		}
		else if(projectname.equals("CET") && approvalstatus.equals("Approved"))
		{
			String pname1 = "AssetMark Backoffice";
			String pname2 = "Investment";
			String pname3 = "CET Applications Support";
			String pname4 = "QA Project";
			String status = "Approved";
		    return allowancedashboardrepository.getAllowanceDashBoardCETApproved(pname1,pname2,pname3,pname4,status,startdate,enddate,pmname);	
		}
		else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("Approved"))
		{
			String pname1 = "AssetMark infra Services";
			String pname2 = "Investment Operations";
			String pname3 = "eSigna";
			String pname4 = "Sitecore";
			String pname5 = "SFDC";
			String pname6 = "OKTA Implementation";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardEPApproved(pname1,pname2,pname3,pname4,pname5,pname6,status,startdate,enddate,pmname);
		}
		else if(projectname.equals("Data") && approvalstatus.equals("Approved"))
		{
			String pname1 = "HNW Reporting and Enhancements";
			String pname2 = "Integrated Digital Insights Squad";
			String pname3 = "Batch Processing";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardDataApproved(pname1,pname2,pname3,status,startdate,enddate,pmname);
		}
		else if(projectname.equals("Digital") && approvalstatus.equals("Approved"))
		{
			String pname1 = "Digital User Experience";
			String pname2 = "IT Platforms";
			String pname3 = "Digital Applications";
			String pname4 = "DevOps";
			String pname5 = "Ops Enhancements";
			String pname6 = "App Dev";
			String pname7 = "Savos Personal Portfolios";
			String pname8 = "Delivery Management_AssetMark";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardDigitalApproved(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,status,startdate,enddate,pmname);
		}
		else if(projectname.equals("CET") && approvalstatus.equals("UnApproved"))
		{
			String pname1 = "AssetMark Backoffice";
			String pname2 = "Investment";
			String pname3 = "CET Applications Support";
			String pname4 = "QA Project";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardCETUnapproved(pname1,pname2,pname3,pname4,status,startdate,enddate,pmname);		
		}
		else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("UnApproved"))
		{
			String pname1 = "AssetMark infra Services";
			String pname2 = "Investment Operations";
			String pname3 = "eSigna";
			String pname4 = "Sitecore";
			String pname5 = "SFDC";
			String pname6 = "OKTA Implementation";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardEPUnapproved(pname1,pname2,pname3,pname4,pname5,pname6,status,startdate,enddate,pmname);
		}
		else if(projectname.equals("Data") && approvalstatus.equals("UnApproved"))
		{
			String pname1 = "HNW Reporting and Enhancements";
			String pname2 = "Integrated Digital Insights Squad";
			String pname3 = "Batch Processing";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardDataUnapproved(pname1,pname2,pname3,status,startdate,enddate,pmname);
		}
		else if(projectname.equals("Digital") && approvalstatus.equals("UnApproved"))
		{
			String pname1 = "Digital User Experience";
			String pname2 = "IT Platforms";
			String pname3 = "Digital Applications";
			String pname4 = "DevOps";
			String pname5 = "Ops Enhancements";
			String pname6 = "App Dev";
			String pname7 = "Savos Personal Portfolios";
			String pname8 = "Delivery Management_AssetMark";
			String status = "Approved";
			return allowancedashboardrepository.getAllowanceDashBoardDigitalUnapproved(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,status,startdate,enddate,pmname);
		}
		return null;
	}
	
	//superuser
	public List<AllowanceDashBoard> getAllowanceDashBoardByPnSdEdAsNpm(String projectname,String startdate,String enddate,String approvalstatus)
    {
        if(projectname.equals("CET")  && approvalstatus.equals("All"))
        {
            String pname1 = "AssetMark Backoffice";
            String pname2 = "Investment";
            String pname3 = "CET Applications Support";
            String pname4 = "QA Project";
            return allowancedashboardrepository.getAllowanceDashBoardCETALLNpm(pname1,pname2,pname3,pname4,startdate,enddate);    
        }
        else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("All"))
        {
            String pname1 = "AssetMark infra Services";
            String pname2 = "Investment Operations";
            String pname3 = "eSigna";
            String pname4 = "Sitecore";
            String pname5 = "SFDC";
            String pname6 = "OKTA Implementation";
            return allowancedashboardrepository.getAllowanceDashBoardEPALLNpm(pname1,pname2,pname3,pname4,pname5,pname6,startdate,enddate);
        }
        else if(projectname.equals("Data") && approvalstatus.equals("All"))
        {
            System.out.println(projectname+" "+approvalstatus+" "+startdate+" "+enddate);
            String pname1 = "HNW Reporting and Enhancements";
            String pname2 = "Integrated Digital Insights Squad";
            String pname3 = "Batch Processing";
            return allowancedashboardrepository.getAllowanceDashBoardDataALLNpm(pname1,pname2,pname3,startdate,enddate);
        }
        else if(projectname.equals("Digital") && approvalstatus.equals("All"))
        {
            String pname1 = "Digital User Experience";
            String pname2 = "IT Platforms";
            String pname3 = "Digital Applications";
            String pname4 = "DevOps";
            String pname5 = "Ops Enhancements";
            String pname6 = "App Dev";
            String pname7 = "Savos Personal Portfolios";
            String pname8 = "Delivery Management_AssetMark";
            return allowancedashboardrepository.getAllowanceDashBoardDigitalALLNpm(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,startdate,enddate);
        }
        else if(projectname.equals("CET") && approvalstatus.equals("Approved"))
        {
            String pname1 = "AssetMark Backoffice";
            String pname2 = "Investment";
            String pname3 = "CET Applications Support";
            String pname4 = "QA Project";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardCETApprovedNpm(pname1,pname2,pname3,pname4,status,startdate,enddate);    
        }
        else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("Approved"))
        {
            String pname1 = "AssetMark infra Services";
            String pname2 = "Investment Operations";
            String pname3 = "eSigna";
            String pname4 = "Sitecore";
            String pname5 = "SFDC";
            String pname6 = "OKTA Implementation";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardEPApprovedNpm(pname1,pname2,pname3,pname4,pname5,pname6,status,startdate,enddate);
        }
        else if(projectname.equals("Data") && approvalstatus.equals("Approved"))
        {
            String pname1 = "HNW Reporting and Enhancements";
            String pname2 = "Integrated Digital Insights Squad";
            String pname3 = "Batch Processing";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardDataApprovedNpm(pname1,pname2,pname3,status,startdate,enddate);
        }
else if(projectname.equals("Digital") && approvalstatus.equals("Approved"))
        {
            String pname1 = "Digital User Experience";
            String pname2 = "IT Platforms";
            String pname3 = "Digital Applications";
            String pname4 = "DevOps";
            String pname5 = "Ops Enhancements";
            String pname6 = "App Dev";
            String pname7 = "Savos Personal Portfolios";
            String pname8 = "Delivery Management_AssetMark";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardDigitalApprovedNpm(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,status,startdate,enddate);
        }
        else if(projectname.equals("CET") && approvalstatus.equals("UnApproved"))
        {
            String pname1 = "AssetMark Backoffice";
            String pname2 = "Investment";
            String pname3 = "CET Applications Support";
            String pname4 = "QA Project";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardCETUnapprovedNpm(pname1,pname2,pname3,pname4,status,startdate,enddate);        
        }
        else if(projectname.equals("Enterprise Platforms") && approvalstatus.equals("UnApproved"))
        {
            String pname1 = "AssetMark infra Services";
            String pname2 = "Investment Operations";
            String pname3 = "eSigna";
            String pname4 = "Sitecore";
            String pname5 = "SFDC";
            String pname6 = "OKTA Implementation";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardEPUnapprovedNpm(pname1,pname2,pname3,pname4,pname5,pname6,status,startdate,enddate);
        }
        else if(projectname.equals("Data") && approvalstatus.equals("UnApproved"))
        {
            String pname1 = "HNW Reporting and Enhancements";
            String pname2 = "Integrated Digital Insights Squad";
            String pname3 = "Batch Processing";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardDataUnapprovedNpm(pname1,pname2,pname3,status,startdate,enddate);
        }
        else if(projectname.equals("Digital") && approvalstatus.equals("UnApproved"))
        {
            String pname1 = "Digital User Experience";
            String pname2 = "IT Platforms";
            String pname3 = "Digital Applications";
            String pname4 = "DevOps";
            String pname5 = "Ops Enhancements";
            String pname6 = "App Dev";
            String pname7 = "Savos Personal Portfolios";
            String pname8 = "Delivery Management_AssetMark";
            String status = "Approved";
            return allowancedashboardrepository.getAllowanceDashBoardDigitalUnapprovedNpm(pname1,pname2,pname3,pname4,pname5,pname6,pname7,pname8,status,startdate,enddate);
        }
        return null;
}

    
}
