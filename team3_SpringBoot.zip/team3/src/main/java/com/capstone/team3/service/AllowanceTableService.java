package com.capstone.team3.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.capstone.team3.entity.AllowanceTable;
import com.capstone.team3.helper.AllowanceHelper;
import com.capstone.team3.repository.AllowanceTableRepository;

@Service
public class AllowanceTableService {
	@Autowired
	private AllowanceTableRepository allowancetablerepository;
	
	public void save(MultipartFile file)
	{
		try 
		{
			List<AllowanceTable> allowancelist = AllowanceHelper.convertExcelToListOfATObjects(file.getInputStream());
			allowancetablerepository.saveAll(allowancelist);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public List<AllowanceTable> getallallowances()
	{
		return allowancetablerepository.findAll();
	}


}
