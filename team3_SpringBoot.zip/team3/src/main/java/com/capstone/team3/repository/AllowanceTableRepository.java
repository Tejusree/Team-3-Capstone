package com.capstone.team3.repository;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstone.team3.entity.AllowanceTable;

@Repository
public interface AllowanceTableRepository extends JpaRepository<AllowanceTable,Integer>{
	
//	@Query("SELECT a FROM AllowanceTable a where a.projectName = :projectname AND a.periodStart = :startdate AND a.periodEnd = :enddate")
//	List<AllowanceTable> getAllowanceDashBoard(@Param("projectname")String projectname,@Param("startdate")String startdate,@Param("enddate")String enddate);

}
